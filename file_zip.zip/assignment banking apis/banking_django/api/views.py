from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from passlib.context import CryptContext
from datetime import datetime, timedelta
import jwt
import uuid
import json

# JWT config
SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Security utils
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# In-memory databases
users_db = {}     # username -> {username, hashed_password, id}
accounts = {}     # user_id -> balance

# Utils
def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

def create_token(data, expires_delta=None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_current_user(request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        return None
    token = auth_header.split(" ")[1]
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if username not in users_db:
            return None
        return users_db[username]
    except jwt.ExpiredSignatureError:
        return "expired"
    except Exception:
        return None


# 1. Signup
@csrf_exempt
def signup(request):
    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=405)
    try:
        data = json.loads(request.body)
        username = data.get("username")
        password = data.get("password")
    except:
        return JsonResponse({"error": "Invalid JSON"}, status=400)

    if not username or not password:
        return JsonResponse({"error": "Username and password required"}, status=400)

    if username in users_db:
        return JsonResponse({"error": "Username already exists"}, status=400)

    user_id = str(uuid.uuid4())
    users_db[username] = {
        "username": username,
        "hashed_password": get_password_hash(password),
        "id": user_id
    }
    accounts[user_id] = 0.0
    return JsonResponse({"message": "User created", "user_id": user_id})


# 2. Login
@csrf_exempt
def login(request):
    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=405)
    try:
        data = json.loads(request.body)
        username = data.get("username")
        password = data.get("password")
    except:
        return JsonResponse({"error": "Invalid JSON"}, status=400)

    user = users_db.get(username)
    if not user or not verify_password(password, user["hashed_password"]):
        return JsonResponse({"error": "Invalid username or password"}, status=401)

    token = create_token({"sub": user["username"]}, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    return JsonResponse({"access_token": token, "token_type": "bearer"})


# 3. Deposit
@csrf_exempt
def deposit(request):
    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=405)
    current_user = get_current_user(request)
    if current_user is None:
        return JsonResponse({"error": "Invalid or missing token"}, status=401)
    if current_user == "expired":
        return JsonResponse({"error": "Token expired"}, status=401)

    try:
        data = json.loads(request.body)
        amount = float(data.get("amount"))
    except:
        return JsonResponse({"error": "Invalid amount"}, status=400)

    if amount <= 0:
        return JsonResponse({"error": "Amount must be positive"}, status=400)

    accounts[current_user["id"]] += amount
    return JsonResponse({"message": "Deposited", "balance": accounts[current_user["id"]]})


# 4. Withdraw
@csrf_exempt
def withdraw(request):
    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=405)
    current_user = get_current_user(request)
    if current_user is None:
        return JsonResponse({"error": "Invalid or missing token"}, status=401)
    if current_user == "expired":
        return JsonResponse({"error": "Token expired"}, status=401)

    try:
        data = json.loads(request.body)
        amount = float(data.get("amount"))
    except:
        return JsonResponse({"error": "Invalid amount"}, status=400)

    if amount <= 0:
        return JsonResponse({"error": "Amount must be positive"}, status=400)
    if amount > accounts[current_user["id"]]:
        return JsonResponse({"error": "Insufficient balance"}, status=400)

    accounts[current_user["id"]] -= amount
    return JsonResponse({"message": "Withdrawn", "balance": accounts[current_user["id"]]})


# 5. Balance
def balance(request):
    if request.method != "GET":
        return JsonResponse({"error": "Invalid request method"}, status=405)
    current_user = get_current_user(request)
    if current_user is None:
        return JsonResponse({"error": "Invalid or missing token"}, status=401)
    if current_user == "expired":
        return JsonResponse({"error": "Token expired"}, status=401)

    return JsonResponse({"user_id": current_user["id"], "balance": accounts[current_user["id"]]})
