from sanic import Sanic, response
from sanic.request import Request
from sanic.exceptions import Unauthorized, InvalidUsage
from passlib.context import CryptContext
from datetime import datetime, timedelta
import jwt
import uuid
import json

# App setup
app = Sanic("BankingAPI")

# JWT config
SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Security utils
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# In-memory databases
users_db = {}     # key = username, value = dict with hashed_password, id
accounts = {}     # key = user_id, value = balance


# Utils
def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

def create_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_current_user(request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise Unauthorized("Missing or invalid token")
    token = auth_header.split(" ")[1]
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if username is None or username not in users_db:
            raise Unauthorized("Invalid token or user")
        return users_db[username]
    except jwt.ExpiredSignatureError:
        raise Unauthorized("Token expired")
    except Exception:
        raise Unauthorized("Invalid token")


# 1. Signup
@app.post("/signup")
async def signup(request):
    try:
        data = request.json
        username = data.get("username")
        password = data.get("password")
    except Exception:
        raise InvalidUsage("Invalid input format")

    if not username or not password:
        return response.json({"error": "Username and password required"}, status=400)

    if username in users_db:
        return response.json({"error": "Username already exists"}, status=400)

    user_id = str(uuid.uuid4())
    users_db[username] = {
        "username": username,
        "hashed_password": get_password_hash(password),
        "id": user_id
    }
    accounts[user_id] = 0.0
    return response.json({"message": "User created", "user_id": user_id})


# 2. Login
@app.post("/login")
async def login(request):
    try:
        data = request.json
        username = data.get("username")
        password = data.get("password")
    except Exception:
        raise InvalidUsage("Invalid input format")

    if not username or not password:
        return response.json({"error": "Username and password required"}, status=400)

    user = users_db.get(username)
    if not user or not verify_password(password, user["hashed_password"]):
        raise Unauthorized("Invalid username or password")

    token = create_token({"sub": user["username"]}, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    return response.json({"access_token": token, "token_type": "bearer"})


# 3. Deposit
@app.post("/deposit")
async def deposit(request):
    current_user = get_current_user(request)
    try:
        data = request.json
        amount = float(data.get("amount"))
    except Exception:
        raise InvalidUsage("Invalid amount")

    if amount <= 0:
        return response.json({"error": "Amount must be positive"}, status=400)

    accounts[current_user["id"]] += amount
    return response.json({"message": "Deposited", "balance": accounts[current_user["id"]]})


# 4. Withdraw
@app.post("/withdraw")
async def withdraw(request):
    current_user = get_current_user(request)
    try:
        data = request.json
        amount = float(data.get("amount"))
    except Exception:
        raise InvalidUsage("Invalid amount")

    if amount <= 0:
        return response.json({"error": "Amount must be positive"}, status=400)

    if amount > accounts[current_user["id"]]:
        return response.json({"error": "Insufficient balance"}, status=400)

    accounts[current_user["id"]] -= amount
    return response.json({"message": "Withdrawn", "balance": accounts[current_user["id"]]})


# 5. Balance
@app.get("/balance")
async def get_balance(request):
    current_user = get_current_user(request)
    return response.json({"user_id": current_user["id"], "balance": accounts[current_user["id"]]})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
