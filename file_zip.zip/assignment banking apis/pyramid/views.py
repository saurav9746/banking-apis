from pyramid.view import view_config
from pyramid.response import Response
import json
from .models import users_db, accounts, get_password_hash, verify_password, create_token, decode_token, ACCESS_TOKEN_EXPIRE_MINUTES

def json_body(request):
    try:
        return request.json_body
    except Exception:
        return {}

def get_token(request):
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        return auth_header[7:]
    return None

def get_current_user(request):
    token = get_token(request)
    if not token:
        return None, Response(json.dumps({"error": "Missing token"}), status=401, content_type='application/json')
    user = decode_token(token)
    if user == "expired":
        return None, Response(json.dumps({"error": "Token expired"}), status=401, content_type='application/json')
    if user is None:
        return None, Response(json.dumps({"error": "Invalid token"}), status=401, content_type='application/json')
    return user, None

@view_config(route_name='signup', request_method='POST', renderer='json')
def signup(request):
    data = json_body(request)
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        request.response.status = 400
        return {"error": "username and password required"}

    if username in users_db:
        request.response.status = 400
        return {"error": "Username already exists"}

    user_id = str(uuid.uuid4())
    hashed_password = get_password_hash(password)
    users_db[username] = {"username": username, "hashed_password": hashed_password, "id": user_id}
    accounts[user_id] = 0.0

    request.response.status = 201
    return {"message": "User created", "user_id": user_id}

@view_config(route_name='login', request_method='POST', renderer='json')
def login(request):
    data = json_body(request)
    username = data.get("username")
    password = data.get("password")

    user = users_db.get(username)
    if not user or not verify_password(password, user["hashed_password"]):
        request.response.status = 401
        return {"error": "Invalid username or password"}

    token = create_token({"sub": username}, expires_delta=ACCESS_TOKEN_EXPIRE_MINUTES)
    return {"access_token": token, "token_type": "bearer"}

@view_config(route_name='deposit', request_method='POST', renderer='json')
def deposit(request):
    user, error_resp = get_current_user(request)
    if error_resp:
        return error_resp

    data = json_body(request)
    amount = data.get("amount")

    if amount is None or amount <= 0:
        request.response.status = 400
        return {"error": "Amount must be positive"}

    accounts[user["id"]] += amount
    return {"message": "Deposited", "balance": accounts[user["id"]]}

@view_config(route_name='withdraw', request_method='POST', renderer='json')
def withdraw(request):
    user, error_resp = get_current_user(request)
    if error_resp:
        return error_resp

    data = json_body(request)
    amount = data.get("amount")

    if amount is None or amount <= 0:
        request.response.status = 400
        return {"error": "Amount must be positive"}

    if amount > accounts[user["id"]]:
        request.response.status = 400
        return {"error": "Insufficient balance"}

    accounts[user["id"]] -= amount
    return {"message": "Withdrawn", "balance": accounts[user["id"]]}

@view_config(route_name='balance', request_method='GET', renderer='json')
def balance(request):
    user, error_resp = get_current_user(request)
    if error_resp:
        return error_resp

    return {"user_id": user["id"], "balance": accounts[user["id"]]}
