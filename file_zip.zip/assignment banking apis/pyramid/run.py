from waitress import serve
from pyramid.config import Configurator

def main(global_config=None, **settings):
    config = Configurator(settings=settings)
    config.add_route('signup', '/signup')
    config.add_route('login', '/login')
    config.add_route('deposit', '/deposit')
    config.add_route('withdraw', '/withdraw')
    config.add_route('balance', '/balance')
    config.scan()  # Make sure views are in this same folder/module
    return config.make_wsgi_app()

if __name__ == '__main__':
    app = main()
    print("Starting server on http://localhost:6543/")
    serve(app, host='0.0.0.0', port=6543)
