from tg import TGController, expose, request, response
from tg.exceptions import HTTPError

from wsgiref.simple_server import make_server
from passlib.context import CryptContext
import jwt
import uuid
from datetime import datetime, timedelta
from pyramid.config import Configurator

# JWT and password config
SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# In-memory storage
users_db = {}    # username -> user dict
accounts = {}    # user_id -> balance

# Utility functions
def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

def create_token(data, expires_delta=None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_token_from_header():
    auth = request.headers.get("Authorization")
    if auth and auth.startswith("Bearer "):
        return auth.split(" ")[1]
    return None

def get_current_user():
    token = get_token_from_header()
    if not token:
        response.status_int = 401
        return None, {"error": "Missing token"}
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if username is None or username not in users_db:
            response.status_int = 401
            return None, {"error": "Invalid token or user"}
        return users_db[username], None
    except jwt.ExpiredSignatureError:
        response.status_int = 401
        return None, {"error": "Token expired"}
    except Exception:
        response.status_int = 401
        return None, {"error": "Invalid token"}

# Controller
class RootController(TGController):

    @expose('json')
    def index(self):
        return {"message": "TurboGears API running"}

    @expose('json')
    def signup(self):
        data = request.json_body
        username = data.get("username")
        password = data.get("password")
        if not username or not password:
            response.status_int = 400
            return {"error": "username and password required"}
        if username in users_db:
            response.status_int = 400
            return {"error": "Username already exists"}

        user_id = str(uuid.uuid4())
        hashed_password = get_password_hash(password)
        users_db[username] = {"username": username, "hashed_password": hashed_password, "id": user_id}
        accounts[user_id] = 0.0
        response.status_int = 201
        return {"message": "User created", "user_id": user_id}

    @expose('json')
    def login(self):
        data = request.json_body
        username = data.get("username")
        password = data.get("password")
        user = users_db.get(username)
        if not user or not verify_password(password, user["hashed_password"]):
            response.status_int = 401
            return {"error": "Invalid username or password"}

        token = create_token({"sub": username}, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
        return {"access_token": token, "token_type": "bearer"}

    @expose('json')
    def deposit(self):
        user, err = get_current_user()
        if err:
            return err

        data = request.json_body
        amount = data.get("amount")
        if amount is None or amount <= 0:
            response.status_int = 400
            return {"error": "Amount must be positive"}

        accounts[user["id"]] += amount
        return {"message": "Deposited", "balance": accounts[user["id"]]}

    @expose('json')
    def withdraw(self):
        user, err = get_current_user()
        if err:
            return err

        data = request.json_body
        amount = data.get("amount")
        if amount is None or amount <= 0:
            response.status_int = 400
            return {"error": "Amount must be positive"}

        if amount > accounts[user["id"]]:
            response.status_int = 400
            return {"error": "Insufficient balance"}

        accounts[user["id"]] -= amount
        return {"message": "Withdrawn", "balance": accounts[user["id"]]}

    @expose('json')
    def balance(self):
        # Manually validate token here for consistency
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            raise HTTPError(401, "Authorization header missing or invalid")

        token = auth_header.split(' ')[1]
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            username = payload.get("sub")
            if username is None or username not in users_db:
                raise HTTPError(401, "Invalid token or user")

            user = users_db[username]
            user_id = user["id"]
            balance = accounts.get(user_id, 0.0)
            return {"user_id": user_id, "balance": balance}

        except jwt.ExpiredSignatureError:
            raise HTTPError(401, "Token expired")
        except Exception:
            raise HTTPError(401, "Invalid token")

if __name__ == '__main__':
    with Configurator() as config:
        root = RootController()
        config.add_route('index', '/')
        config.add_route('signup', '/signup')
        config.add_route('login', '/login')
        config.add_route('deposit', '/deposit')
        config.add_route('withdraw', '/withdraw')
        config.add_route('balance', '/balance')

        config.scan()

        app = config.make_wsgi_app()
        print("Starting TurboGears on http://localhost:9090")
        server = make_server('127.0.0.1', 9090, app)
        server.serve_forever()
