from flask import Flask, request, jsonify
from passlib.context import CryptContext
import jwt
import uuid
from datetime import datetime, timedelta
from functools import wraps

app = Flask(__name__)

SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

users_db = {}  # username -> {username, hashed_password, id}
accounts = {}  # user_id -> balance

def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

def create_token(data, expires_delta=None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith("Bearer "):
                token = auth_header.split(" ")[1]
        if not token:
            return jsonify({"message": "Token is missing!"}), 401
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            username = payload.get("sub")
            if username is None or username not in users_db:
                return jsonify({"message": "Invalid token or user"}), 401
            current_user = users_db[username]
        except jwt.ExpiredSignatureError:
            return jsonify({"message": "Token expired"}), 401
        except Exception:
            return jsonify({"message": "Invalid token"}), 401
        return f(current_user, *args, **kwargs)
    return decorated

@app.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    if username in users_db:
        return jsonify({"message": "Username already exists"}), 400
    user_id = str(uuid.uuid4())
    hashed_password = get_password_hash(password)
    users_db[username] = {"username": username, "hashed_password": hashed_password, "id": user_id}
    accounts[user_id] = 0.0
    return jsonify({"message": "User created", "user_id": user_id})

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    user = users_db.get(username)
    if not user or not verify_password(password, user["hashed_password"]):
        return jsonify({"message": "Invalid username or password"}), 401
    token = create_token({"sub": username}, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    return jsonify({"access_token": token, "token_type": "bearer"})

@app.route('/deposit', methods=['POST'])
@token_required
def deposit(current_user):
    data = request.get_json()
    amount = data.get("amount")
    if amount is None or amount <= 0:
        return jsonify({"message": "Amount must be positive"}), 400
    accounts[current_user["id"]] += amount
    return jsonify({"message": "Deposited", "balance": accounts[current_user["id"]]})

@app.route('/withdraw', methods=['POST'])
@token_required
def withdraw(current_user):
    data = request.get_json()
    amount = data.get("amount")
    if amount is None or amount <= 0:
        return jsonify({"message": "Amount must be positive"}), 400
    if amount > accounts[current_user["id"]]:
        return jsonify({"message": "Insufficient balance"}), 400
    accounts[current_user["id"]] -= amount
    return jsonify({"message": "Withdrawn", "balance": accounts[current_user["id"]]})

@app.route('/balance', methods=['GET'])
@token_required
def balance(current_user):
    return jsonify({"user_id": current_user["id"], "balance": accounts[current_user["id"]]})

if __name__ == '__main__':
    app.run(debug=True)
