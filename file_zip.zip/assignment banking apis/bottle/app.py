from bottle import Bottle, request, response, run
from passlib.context import CryptContext
import jwt
import uuid
from datetime import datetime, timedelta
import json

app = Bottle()

SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

users_db = {}  # username -> {username, hashed_password, id}
accounts = {}  # user_id -> balance

def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

def create_token(data, expires_delta=None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_token_from_header():
    auth = request.get_header("Authorization")
    if auth and auth.startswith("Bearer "):
        return auth.split(" ")[1]
    return None

def get_current_user():
    token = get_token_from_header()
    if not token:
        response.status = 401
        return None, {"error": "Missing token"}
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if username is None or username not in users_db:
            response.status = 401
            return None, {"error": "Invalid token or user"}
        return users_db[username], None
    except jwt.ExpiredSignatureError:
        response.status = 401
        return None, {"error": "Token expired"}
    except Exception:
        response.status = 401
        return None, {"error": "Invalid token"}

@app.post('/signup')
def signup():
    data = request.json
    if not data:
        response.status = 400
        return {"error": "Missing JSON body"}
    username = data.get("username")
    password = data.get("password")
    if not username or not password:
        response.status = 400
        return {"error": "username and password required"}
    if username in users_db:
        response.status = 400
        return {"error": "Username already exists"}

    user_id = str(uuid.uuid4())
    hashed_password = get_password_hash(password)
    users_db[username] = {"username": username, "hashed_password": hashed_password, "id": user_id}
    accounts[user_id] = 0.0
    response.status = 201
    return {"message": "User created", "user_id": user_id}

@app.post('/login')
def login():
    data = request.json
    if not data:
        response.status = 400
        return {"error": "Missing JSON body"}
    username = data.get("username")
    password = data.get("password")
    user = users_db.get(username)
    if not user or not verify_password(password, user["hashed_password"]):
        response.status = 401
        return {"error": "Invalid username or password"}

    token = create_token({"sub": username}, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    return {"access_token": token, "token_type": "bearer"}

@app.post('/deposit')
def deposit():
    current_user, err = get_current_user()
    if err:
        return err

    data = request.json
    if not data:
        response.status = 400
        return {"error": "Missing JSON body"}

    amount = data.get("amount")
    if amount is None or amount <= 0:
        response.status = 400
        return {"error": "Amount must be positive"}

    accounts[current_user["id"]] += amount
    return {"message": "Deposited", "balance": accounts[current_user["id"]]}

@app.post('/withdraw')
def withdraw():
    current_user, err = get_current_user()
    if err:
        return err

    data = request.json
    if not data:
        response.status = 400
        return {"error": "Missing JSON body"}

    amount = data.get("amount")
    if amount is None or amount <= 0:
        response.status = 400
        return {"error": "Amount must be positive"}

    if amount > accounts[current_user["id"]]:
        response.status = 400
        return {"error": "Insufficient balance"}

    accounts[current_user["id"]] -= amount
    return {"message": "Withdrawn", "balance": accounts[current_user["id"]]}

@app.get('/balance')
def balance():
    current_user, err = get_current_user()
    if err:
        return err
    return {"user_id": current_user["id"], "balance": accounts[current_user["id"]]}

if __name__ == '__main__':
    run(app, host='127.0.0.1', port=8080, debug=True)
