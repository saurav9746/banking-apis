import falcon
import json
from passlib.context import CryptContext
import jwt
import uuid
from datetime import datetime, timedelta

SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

users_db = {}  # username -> dict with username, hashed_password, id
accounts = {}  # user_id -> balance

def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

def create_token(data, expires_delta=None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_token_from_header(req):
    auth = req.get_header("Authorization")
    if auth and auth.startswith("Bearer "):
        return auth.split(" ")[1]
    return None

def authenticate(req, resp, resource, params):
    token = get_token_from_header(req)
    if not token:
        raise falcon.HTTPUnauthorized(description="Missing token")

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if username is None or username not in users_db:
            raise falcon.HTTPUnauthorized(description="Invalid token or user")
        req.context["current_user"] = users_db[username]
    except jwt.ExpiredSignatureError:
        raise falcon.HTTPUnauthorized(description="Token expired")
    except Exception:
        raise falcon.HTTPUnauthorized(description="Invalid token")

class SignupResource:
    def on_post(self, req, resp):
        raw_json = req.bounded_stream.read()
        data = json.loads(raw_json.decode("utf-8"))

        username = data.get("username")
        password = data.get("password")
        if not username or not password:
            resp.status = falcon.HTTP_400
            resp.media = {"detail": "username and password required"}
            return

        if username in users_db:
            resp.status = falcon.HTTP_400
            resp.media = {"detail": "Username already exists"}
            return

        user_id = str(uuid.uuid4())
        users_db[username] = {
            "username": username,
            "hashed_password": get_password_hash(password),
            "id": user_id
        }
        accounts[user_id] = 0.0
        resp.status = falcon.HTTP_201
        resp.media = {"message": "User created", "user_id": user_id}

class LoginResource:
    def on_post(self, req, resp):
        raw_json = req.bounded_stream.read()
        data = json.loads(raw_json.decode("utf-8"))

        username = data.get("username")
        password = data.get("password")

        user = users_db.get(username)
        if not user or not verify_password(password, user["hashed_password"]):
            resp.status = falcon.HTTP_401
            resp.media = {"detail": "Invalid username or password"}
            return

        token = create_token({"sub": username}, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
        resp.media = {"access_token": token, "token_type": "bearer"}

class DepositResource:
    @falcon.before(authenticate)
    def on_post(self, req, resp):
        raw_json = req.bounded_stream.read()
        data = json.loads(raw_json.decode("utf-8"))
        amount = data.get("amount")

        if amount is None or amount <= 0:
            resp.status = falcon.HTTP_400
            resp.media = {"detail": "Amount must be positive"}
            return

        current_user = req.context["current_user"]
        accounts[current_user["id"]] += amount

        resp.media = {"message": "Deposited", "balance": accounts[current_user["id"]]}

class WithdrawResource:
    @falcon.before(authenticate)
    def on_post(self, req, resp):
        raw_json = req.bounded_stream.read()
        data = json.loads(raw_json.decode("utf-8"))
        amount = data.get("amount")

        if amount is None or amount <= 0:
            resp.status = falcon.HTTP_400
            resp.media = {"detail": "Amount must be positive"}
            return

        current_user = req.context["current_user"]
        if amount > accounts[current_user["id"]]:
            resp.status = falcon.HTTP_400
            resp.media = {"detail": "Insufficient balance"}
            return

        accounts[current_user["id"]] -= amount
        resp.media = {"message": "Withdrawn", "balance": accounts[current_user["id"]]}

class BalanceResource:
    @falcon.before(authenticate)
    def on_get(self, req, resp):
        current_user = req.context["current_user"]
        resp.media = {"user_id": current_user["id"], "balance": accounts[current_user["id"]]}

app = falcon.App()

app.add_route("/signup", SignupResource())
app.add_route("/login", LoginResource())
app.add_route("/deposit", DepositResource())
app.add_route("/withdraw", WithdrawResource())
app.add_route("/balance", BalanceResource())
