import morepath
from banking_morepath import app  # ✅ Corrected import

def main():
    morepath.scan(app)
    morepath.commit(app.App)
    morepath.run(app.App(), host="127.0.0.1", port=5000)

if __name__ == "__main__":
    main()
