import morepath

# ---------- Models ----------
class Account:
    def __init__(self, id, username, password, balance):
        self.id = id
        self.username = username
        self.password = password
        self.balance = balance

# In-memory "database"
accounts = {
    1: Account(1, "Alice", "alicepass", 5000),
    2: Account(2, "Bob", "bobpass", 3000)
}

# ---------- Morepath App ----------
class App(morepath.App):
    pass

# ---------- Views & Paths ----------

# ✅ View single account
@App.json(model=Account)
def account_view(self, request):
    return {"id": self.id, "username": self.username, "balance": self.balance}

@App.path(model=Account, path="account/{id}", converters=dict(id=int))
def get_account(id):
    return accounts.get(id)

# ✅ List all accounts
@App.json(path="accounts", request_method="GET")
def list_accounts(request):
    return [
        {"id": acc.id, "username": acc.username, "balance": acc.balance}
        for acc in accounts.values()
    ]

# ✅ Signup (create account with username/password)
@App.json(path="signup", request_method="POST")
def signup(request):
    data = request.json
    new_id = max(accounts.keys()) + 1 if accounts else 1
    acc = Account(
        id=new_id,
        username=data["username"],
        password=data["password"],
        balance=data.get("balance", 0)
    )
    accounts[new_id] = acc
    return {
        "message": "Signup successful",
        "account": {"id": acc.id, "username": acc.username, "balance": acc.balance}
    }

# ✅ Update account
@App.json(path="account/{id}/update", request_method="PUT", converters=dict(id=int))
def update_account(request, id):
    data = request.json
    acc = accounts.get(id)
    if not acc:
        return {"error": "Account not found"}
    acc.username = data["username"]
    acc.balance = data["balance"]
    return {
        "message": "Account updated",
        "account": {"id": acc.id, "username": acc.username, "balance": acc.balance}
    }

# ✅ Delete account
@App.json(path="account/{id}/delete", request_method="DELETE", converters=dict(id=int))
def delete_account(request, id):
    if id in accounts:
        del accounts[id]
        return {"message": "Account deleted"}
    return {"error": "Account not found"}

# ✅ Deposit
@App.json(path="account/{id}/deposit", request_method="POST", converters=dict(id=int))
def deposit(request, id):
    data = request.json
    acc = accounts.get(id)
    if not acc:
        return {"error": "Account not found"}
    acc.balance += data["amount"]
    return {"message": "Deposit successful", "new_balance": acc.balance}

# ✅ Withdraw
@App.json(path="account/{id}/withdraw", request_method="POST", converters=dict(id=int))
def withdraw(request, id):
    data = request.json
    acc = accounts.get(id)
    if not acc:
        return {"error": "Account not found"}
    if acc.balance < data["amount"]:
        return {"error": "Insufficient funds"}
    acc.balance -= data["amount"]
    return {"message": "Withdrawal successful", "new_balance": acc.balance}

# ✅ Transfer
@App.json(path="account/transfer", request_method="POST")
def transfer(request):
    data = request.json
    from_acc = accounts.get(data["from_id"])
    to_acc = accounts.get(data["to_id"])
    amount = data["amount"]

    if not from_acc or not to_acc:
        return {"error": "Account not found"}
    if from_acc.balance < amount:
        return {"error": "Insufficient funds"}
    
    from_acc.balance -= amount
    to_acc.balance += amount

    return {
        "message": "Transfer successful",
        "from_balance": from_acc.balance,
        "to_balance": to_acc.balance
    }
